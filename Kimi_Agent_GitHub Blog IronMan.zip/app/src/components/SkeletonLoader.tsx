export default function SkeletonLoader({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="flex flex-col gap-3">
          <div className="skeleton-pulse aspect-[4/3] rounded-lg" />
          <div className="skeleton-pulse h-6 rounded w-3/4" />
          <div className="skeleton-pulse h-4 rounded w-full" />
          <div className="skeleton-pulse h-4 rounded w-2/3" />
          <div className="flex gap-2 mt-1">
            <div className="skeleton-pulse h-5 rounded w-16" />
            <div className="skeleton-pulse h-5 rounded w-14" />
          </div>
        </div>
      ))}
    </div>
  );
}
