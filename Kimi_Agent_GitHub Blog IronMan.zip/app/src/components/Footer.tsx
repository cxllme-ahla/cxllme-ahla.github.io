import { Link } from "react-router-dom";

const navLinks = [
  { label: "Home", path: "/" },
  { label: "Archive", path: "/archive" },
  { label: "About", path: "/about" },
  { label: "Contact", path: "/contact" },
  { label: "RSS Feed", path: "/rss.xml" },
];

const socialLinks = [
  { label: "Twitter / X", href: "https://twitter.com" },
  { label: "GitHub", href: "https://github.com" },
  { label: "LinkedIn", href: "https://linkedin.com" },
];

export default function Footer() {
  return (
    <footer className="border-t border-[#262626]">
      <div className="max-w-[1440px] mx-auto px-[clamp(20px,4vw,40px)] py-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Column 1: Brand */}
          <div>
            <Link
              to="/"
              className="font-serif text-[24px] font-normal text-white hover:text-[#d4af37] transition-colors"
            >
              StarkInsider
            </Link>
            <p className="mt-3 text-[14px] text-[#888888] font-sans leading-relaxed max-w-[280px]">
              Premium editorial technology blog covering culture, technology,
              cinema, and gaming with in-depth analysis and reviews.
            </p>
          </div>

          {/* Column 2: Navigation */}
          <div>
            <h3 className="text-[14px] font-medium uppercase tracking-[0.02em] text-[#888888] mb-4 font-sans">
              Navigation
            </h3>
            <ul className="flex flex-col gap-3">
              {navLinks.map((link) => (
                <li key={link.label}>
                  {link.path === "/rss.xml" ? (
                    <a
                      href={link.path}
                      className="text-[14px] text-[#888888] hover:text-white transition-colors font-sans"
                    >
                      {link.label}
                    </a>
                  ) : (
                    <Link
                      to={link.path}
                      className="text-[14px] text-[#888888] hover:text-white transition-colors font-sans"
                    >
                      {link.label}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Social */}
          <div>
            <h3 className="text-[14px] font-medium uppercase tracking-[0.02em] text-[#888888] mb-4 font-sans">
              Connect
            </h3>
            <ul className="flex flex-col gap-3">
              {socialLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[14px] text-[#888888] hover:text-white transition-colors font-sans"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom row */}
        <div className="mt-16 pt-6 border-t border-[#262626] flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-[12px] text-[#888888] font-sans">
            2025 StarkInsider. All rights reserved.
          </p>
          <div className="flex items-center gap-2 text-[12px] text-[#888888] font-sans">
            <Link to="/" className="hover:text-white transition-colors">
              Home
            </Link>
            <span>/</span>
            <Link to="/archive" className="hover:text-white transition-colors">
              Archive
            </Link>
            <span>/</span>
            <Link to="/about" className="hover:text-white transition-colors">
              About
            </Link>
            <span>/</span>
            <Link
              to="/contact"
              className="hover:text-white transition-colors"
            >
              Contact
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
