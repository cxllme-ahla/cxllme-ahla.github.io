import { useState, useEffect, useRef, useCallback } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Search, Menu, X } from "lucide-react";
import { searchPosts, posts } from "@/data/posts";

const navLinks = [
  { label: "Home", path: "/" },
  { label: "Archive", path: "/archive" },
  { label: "About", path: "/about" },
  { label: "Contact", path: "/contact" },
];

export default function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<typeof posts>([]);
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (searchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [searchOpen]);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const handleSearch = useCallback(
    (query: string) => {
      setSearchQuery(query);
      if (query.trim().length > 0) {
        setSearchResults(searchPosts(query));
      } else {
        setSearchResults([]);
      }
    },
    []
  );

  const handleResultClick = (slug: string) => {
    setSearchOpen(false);
    setSearchQuery("");
    navigate(`/post/${slug}`);
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setSearchOpen(false);
        setMobileOpen(false);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  return (
    <>
      <nav className="sticky top-0 z-50 h-[60px] bg-[rgba(2,2,2,0.8)] backdrop-blur-[12px] border-b border-[#262626]">
        <div className="max-w-[1440px] mx-auto px-[clamp(20px,4vw,40px)] h-full flex items-center justify-between">
          {/* Logo */}
          <Link
            to="/"
            className="font-serif text-[20px] font-normal uppercase tracking-[0.05em] text-white hover:text-[#d4af37] transition-colors"
          >
            StarkInsider
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`relative font-sans text-[14px] font-medium uppercase tracking-[0.02em] transition-colors ${
                  location.pathname === link.path
                    ? "text-white"
                    : "text-[#888888] hover:text-white"
                }`}
              >
                {link.label}
                {location.pathname === link.path && (
                  <span className="absolute -bottom-[18px] left-0 w-full h-[1px] bg-[#d4af37]" />
                )}
              </Link>
            ))}
          </div>

          {/* Right side */}
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSearchOpen(true)}
              className="text-[#888888] hover:text-white transition-colors p-1"
              aria-label="Search"
            >
              <Search size={20} />
            </button>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden text-[#888888] hover:text-white transition-colors p-1"
              aria-label="Menu"
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div className="md:hidden absolute top-[60px] left-0 right-0 bg-[rgba(2,2,2,0.95)] backdrop-blur-[12px] border-b border-[#262626]">
            <div className="flex flex-col p-6 gap-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`font-sans text-[14px] font-medium uppercase tracking-[0.02em] ${
                    location.pathname === link.path
                      ? "text-white"
                      : "text-[#888888]"
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Search Overlay */}
      {searchOpen && (
        <div
          className="fixed inset-0 z-[100] bg-[rgba(2,2,2,0.95)] flex flex-col items-center pt-[15vh]"
          onClick={() => setSearchOpen(false)}
        >
          <button
            onClick={() => setSearchOpen(false)}
            className="absolute top-6 right-6 text-[#888888] hover:text-white transition-colors"
          >
            <X size={28} />
          </button>
          <div
            className="w-full max-w-2xl px-6"
            onClick={(e) => e.stopPropagation()}
          >
            <input
              ref={searchInputRef}
              type="text"
              placeholder="Search articles..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full bg-transparent border-b border-[#262626] focus:border-[#d4af37] outline-none font-serif text-[48px] text-white placeholder-[#888888] pb-4 transition-colors"
            />
            <div className="mt-6 max-h-[50vh] overflow-y-auto">
              {searchResults.length > 0 ? (
                <div className="flex flex-col gap-4">
                  {searchResults.map((post) => (
                    <button
                      key={post.slug}
                      onClick={() => handleResultClick(post.slug)}
                      className="text-left p-4 rounded-lg hover:bg-[#0a0a0a] transition-colors group"
                    >
                      <h3 className="font-serif text-[20px] text-white group-hover:text-[#d4af37] transition-colors">
                        {post.title}
                      </h3>
                      <p className="text-[#888888] text-[14px] mt-1 line-clamp-2">
                        {post.excerpt}
                      </p>
                      <div className="flex gap-2 mt-2">
                        {post.tags.slice(0, 3).map((tag) => (
                          <span
                            key={tag}
                            className="text-[11px] text-[#888888] border border-[#262626] rounded px-2 py-0.5"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </button>
                  ))}
                </div>
              ) : searchQuery.trim().length > 0 ? (
                <p className="text-[#888888] text-[14px]">
                  No articles found for "{searchQuery}"
                </p>
              ) : (
                <p className="text-[#888888] text-[14px]">
                  Start typing to search articles...
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
