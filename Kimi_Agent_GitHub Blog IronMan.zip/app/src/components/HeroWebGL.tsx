import { useEffect, useRef } from "react";

const VERTEX_SHADER = `
precision highp float;
attribute vec2 uv;
attribute vec3 position;
attribute vec3 normal;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform vec2 uMouse;
uniform float uSpeed;
uniform float uTime;
varying vec3 vNormal;
varying vec2 vUv;
varying vec3 vViewPosition;

mat4 rotationMatrix(vec3 axis, float angle) {
  axis = normalize(axis);
  float s = sin(angle);
  float c = cos(angle);
  float oc = 1.0 - c;
  return mat4(
    oc * axis.x * axis.x + c,           oc * axis.x * axis.y - axis.z * s,  oc * axis.z * axis.x + axis.y * s,  0.0,
    oc * axis.x * axis.y + axis.z * s,  oc * axis.y * axis.y + c,           oc * axis.y * axis.z - axis.x * s,  0.0,
    oc * axis.z * axis.x - axis.y * s,  oc * axis.y * axis.z + axis.x * s,  oc * axis.z * axis.z + c,           0.0,
    0.0,                                  0.0,                                  0.0,                                  1.0
  );
}

vec3 rotate(vec3 v, vec3 axis, float angle) {
  mat4 m = rotationMatrix(axis, angle);
  return (m * vec4(v, 1.0)).xyz;
}

void main() {
  vUv = uv;
  vec3 newPosition = position;
  float xDist = distance(vec2(0.0), vec2(position.y, position.z));
  newPosition.x -= cos(xDist * 1.0 - uTime * 0.3 + uMouse.x) * 1.2;
  float yDist = distance(vec2(0.0), vec2(position.x, position.z));
  newPosition.y -= sin(yDist * 1.0 - uTime * 0.3 + uMouse.y) * 1.2;
  newPosition = rotate(newPosition, vec3(0.0, 0.0, 1.0), uMouse.x * position.x * 0.0001);
  newPosition = rotate(newPosition, vec3(1.0, 0.0, 0.0), -uMouse.y * position.x * 0.0001);
  newPosition = rotate(newPosition, vec3(0.0, 1.0, 0.0), uMouse.x * position.x * 0.001);
  newPosition = rotate(newPosition, vec3(1.0, 0.0, 0.0), -uMouse.y * position.y * 0.001);
  vec4 mvPosition = modelViewMatrix * vec4(newPosition, 1.0);
  gl_Position = projectionMatrix * mvPosition;
  vViewPosition = -mvPosition.xyz;
  vNormal = normal;
}
`;

const FRAGMENT_SHADER = `
precision highp float;
uniform sampler2D uCanvas;
uniform sampler2D uLetters;
uniform float uSpeed;
uniform float uTime;
uniform float uScrollY;
varying vec2 vUv;
varying vec3 vNormal;
varying vec3 vViewPosition;

void main() {
  float wordHeight = 0.0769;
  float wordIndex = 0.0;
  vec2 st = vUv;
  st.y = st.y + uScrollY;
  float aspect = 1381.0 / 1002.0;
  st.x = (st.x - 0.5) * aspect + 0.5;
  float wordMix = mod(st.y, wordHeight);
  vec2 wordSt = vec2(st.x, wordMix / wordHeight);
  vec3 letters = texture2D(uLetters, wordSt).rgb;
  vec3 textColor = vec3(0.83, 0.69, 0.22) * (0.4 + letters.r);
  float lighting = max(0.0, dot(normalize(vNormal), normalize(vec3(0.0, 0.0, 1.0))));
  vec3 color = textColor * (0.4 + smoothstep(0.4, 0.5, letters.r));
  gl_FragColor = vec4(color, 1.0);
}
`;

function createTextTexture(
  gl: WebGLRenderingContext,
  text: string,
  font: string
): WebGLTexture | null {
  const canvas = document.createElement("canvas");
  canvas.width = 4096;
  canvas.height = 128;
  const ctx = canvas.getContext("2d");
  if (!ctx) return null;

  ctx.fillStyle = "black";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.font = font;
  ctx.fillStyle = "white";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, canvas.width / 2, canvas.height / 2);

  const texture = gl.createTexture();
  if (!texture) return null;

  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texImage2D(
    gl.TEXTURE_2D,
    0,
    gl.LUMINANCE,
    canvas.width,
    canvas.height,
    0,
    gl.LUMINANCE,
    gl.UNSIGNED_BYTE,
    ctx.getImageData(0, 0, canvas.width, canvas.height).data
  );
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

  return texture;
}

function createCylinderGeometry(
  _gl: WebGLRenderingContext,
  segments: number = 32
) {
  const positions: number[] = [];
  const normals: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];

  const radius = 2.5;
  const height = 1.5;

  for (let i = 0; i <= segments; i++) {
    const theta = (i / segments) * Math.PI * 2;
    const x = Math.cos(theta) * radius;
    const z = Math.sin(theta) * radius;

    for (let j = 0; j <= 1; j++) {
      const y = j * height - height / 2;
      positions.push(x, y, z);
      normals.push(Math.cos(theta), 0, Math.sin(theta));
      uvs.push(i / segments, j);
    }
  }

  for (let i = 0; i < segments; i++) {
    const base = i * 2;
    indices.push(base, base + 1, base + 2);
    indices.push(base + 1, base + 3, base + 2);
  }

  return { positions, normals, uvs, indices };
}

function createShader(
  gl: WebGLRenderingContext,
  type: number,
  source: string
): WebGLShader | null {
  const shader = gl.createShader(type);
  if (!shader) return null;
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    console.error("Shader compile error:", gl.getShaderInfoLog(shader));
    gl.deleteShader(shader);
    return null;
  }
  return shader;
}

function createProgram(
  gl: WebGLRenderingContext,
  vs: WebGLShader,
  fs: WebGLShader
): WebGLProgram | null {
  const program = gl.createProgram();
  if (!program) return null;
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    console.error("Program link error:", gl.getProgramInfoLog(program));
    gl.deleteProgram(program);
    return null;
  }
  return program;
}

export default function HeroWebGL() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const scrollRef = useRef(0);
  const rafRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const gl = canvas.getContext("webgl", {
      alpha: true,
      antialias: true,
    });
    if (!gl) return;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio, 2);
      canvas.width = canvas.offsetWidth * dpr;
      canvas.height = canvas.offsetHeight * dpr;
      gl.viewport(0, 0, canvas.width, canvas.height);
    };
    resize();

    const vs = createShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
    const fs = createShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
    if (!vs || !fs) return;

    const program = createProgram(gl, vs, fs);
    if (!program) return;

    gl.useProgram(program);

    // Create geometry
    const geo = createCylinderGeometry(gl, 32);

    const posBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, posBuffer);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array(geo.positions),
      gl.STATIC_DRAW
    );
    const posLoc = gl.getAttribLocation(program, "position");
    gl.enableVertexAttribArray(posLoc);
    gl.vertexAttribPointer(posLoc, 3, gl.FLOAT, false, 0, 0);

    const normBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, normBuffer);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array(geo.normals),
      gl.STATIC_DRAW
    );
    const normLoc = gl.getAttribLocation(program, "normal");
    gl.enableVertexAttribArray(normLoc);
    gl.vertexAttribPointer(normLoc, 3, gl.FLOAT, false, 0, 0);

    const uvBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, uvBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(geo.uvs), gl.STATIC_DRAW);
    const uvLoc = gl.getAttribLocation(program, "uv");
    gl.enableVertexAttribArray(uvLoc);
    gl.vertexAttribPointer(uvLoc, 2, gl.FLOAT, false, 0, 0);

    const idxBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, idxBuffer);
    gl.bufferData(
      gl.ELEMENT_ARRAY_BUFFER,
      new Uint16Array(geo.indices),
      gl.STATIC_DRAW
    );

    // Create text textures
    const font = '400 80px "Instrument Serif", serif';
    const lettersTexture = createTextTexture(gl, "STARKINSIDER", font);

    // Uniforms
    const uMouse = gl.getUniformLocation(program, "uMouse");
    const uSpeed = gl.getUniformLocation(program, "uSpeed");
    const uTime = gl.getUniformLocation(program, "uTime");
    const uScrollY = gl.getUniformLocation(program, "uScrollY");
    const uModelView = gl.getUniformLocation(program, "modelViewMatrix");
    const uProjection = gl.getUniformLocation(program, "projectionMatrix");
    const uLetters = gl.getUniformLocation(program, "uLetters");

    // Matrices
    function perspective(
      fov: number,
      aspect: number,
      near: number,
      far: number
    ): Float32Array {
      const f = 1.0 / Math.tan(fov / 2);
      const nf = 1 / (near - far);
      return new Float32Array([
        f / aspect, 0, 0, 0,
        0, f, 0, 0,
        0, 0, (far + near) * nf, -1,
        0, 0, 2 * far * near * nf, 0,
      ]);
    }

    function lookAt(
      eye: number[],
      center: number[],
      up: number[]
    ): Float32Array {
      let z0 = eye[0] - center[0];
      let z1 = eye[1] - center[1];
      let z2 = eye[2] - center[2];
      const len = Math.sqrt(z0 * z0 + z1 * z1 + z2 * z2);
      z0 /= len;
      z1 /= len;
      z2 /= len;
      let x0 = up[1] * z2 - up[2] * z1;
      let x1 = up[2] * z0 - up[0] * z2;
      let x2 = up[0] * z1 - up[1] * z0;
      const xlen = Math.sqrt(x0 * x0 + x1 * x1 + x2 * x2);
      x0 /= xlen;
      x1 /= xlen;
      x2 /= xlen;
      const y0 = z1 * x2 - z2 * x1;
      const y1 = z2 * x0 - z0 * x2;
      const y2 = z0 * x1 - z1 * x0;
      return new Float32Array([
        x0, y0, z0, 0,
        x1, y1, z1, 0,
        x2, y2, z2, 0,
        -(x0 * eye[0] + x1 * eye[1] + x2 * eye[2]),
        -(y0 * eye[0] + y1 * eye[1] + y2 * eye[2]),
        -(z0 * eye[0] + z1 * eye[1] + z2 * eye[2]),
        1,
      ]);
    }

    let time = 0;
    const startTime = performance.now();

    const render = () => {
      time = (performance.now() - startTime) * 0.001;

      gl.clearColor(0.008, 0.008, 0.008, 1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      gl.enable(gl.DEPTH_TEST);
      gl.enable(gl.CULL_FACE);

      const aspect = canvas.width / canvas.height;
      const proj = perspective(Math.PI / 4, aspect, 0.1, 100);
      const view = lookAt([0, 0, 6], [0, 0, 0], [0, 1, 0]);

      // modelView = view (no model transform)
      gl.uniformMatrix4fv(uProjection, false, proj);
      gl.uniformMatrix4fv(uModelView, false, view);

      gl.uniform2f(uMouse, mouseRef.current.x, mouseRef.current.y);
      gl.uniform1f(uSpeed, 0.5);
      gl.uniform1f(uTime, time);
      gl.uniform1f(uScrollY, scrollRef.current);

      if (lettersTexture) {
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, lettersTexture);
        gl.uniform1i(uLetters, 0);
      }

      gl.drawElements(gl.TRIANGLES, geo.indices.length, gl.UNSIGNED_SHORT, 0);

      rafRef.current = requestAnimationFrame(render);
    };

    rafRef.current = requestAnimationFrame(render);

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x =
        (e.clientX / window.innerWidth - 0.5) * 2;
      mouseRef.current.y =
        (e.clientY / window.innerHeight - 0.5) * 2;
    };

    const handleWheel = (e: WheelEvent) => {
      scrollRef.current += e.deltaY * 0.001;
    };

    const handleResize = () => {
      resize();
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("wheel", handleWheel, { passive: true });
    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("wheel", handleWheel);
      window.removeEventListener("resize", handleResize);
      gl.deleteProgram(program);
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      if (lettersTexture) gl.deleteTexture(lettersTexture);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: 1,
      }}
    />
  );
}
