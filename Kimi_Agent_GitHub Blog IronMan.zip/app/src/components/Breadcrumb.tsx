import { Link } from "react-router-dom";

interface BreadcrumbProps {
  items: { label: string; path?: string }[];
}

export default function Breadcrumb({ items }: BreadcrumbProps) {
  return (
    <nav className="py-4" aria-label="Breadcrumb">
      <ol className="flex items-center gap-2 text-[12px] font-sans">
        {items.map((item, i) => (
          <li key={i} className="flex items-center gap-2">
            {i > 0 && <span className="text-[#262626]">/</span>}
            {item.path ? (
              <Link
                to={item.path}
                className="text-[#888888] hover:text-white transition-colors link-underline"
              >
                {item.label}
              </Link>
            ) : (
              <span className="text-white truncate max-w-[200px]">
                {item.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}
