import { useEffect, useRef, useState } from "react";

export default function GiscusComments() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Check if giscus is already loaded
    const existing = container.querySelector("script[src*='giscus']");
    if (existing) {
      setLoading(false);
      return;
    }

    const script = document.createElement("script");
    script.src = "https://giscus.app/client.js";
    script.setAttribute("data-repo", "starkinsider/blog-comments");
    script.setAttribute("data-repo-id", "R_kgDON dummy");
    script.setAttribute("data-category", "General");
    script.setAttribute("data-category-id", "DIC_kwDON dummy");
    script.setAttribute("data-mapping", "pathname");
    script.setAttribute("data-strict", "0");
    script.setAttribute("data-reactions-enabled", "1");
    script.setAttribute("data-emit-metadata", "0");
    script.setAttribute("data-input-position", "top");
    script.setAttribute("data-theme", "dark");
    script.setAttribute("data-lang", "en");
    script.setAttribute("data-loading", "lazy");
    script.crossOrigin = "anonymous";
    script.async = true;

    script.onload = () => setLoading(false);

    // Simulate loading since we don't have a real giscus repo
    setTimeout(() => setLoading(false), 1500);

    container.appendChild(script);

    return () => {
      const s = container.querySelector("script[src*='giscus']");
      if (s) s.remove();
    };
  }, []);

  return (
    <div className="mt-16 pt-8 border-t border-[#262626]">
      <h2 className="font-serif text-[32px] text-white mb-8">Discussion</h2>
      {loading ? (
        <div className="flex flex-col gap-4">
          <div className="skeleton-pulse h-4 rounded w-1/3" />
          <div className="skeleton-pulse h-20 rounded w-full" />
          <div className="skeleton-pulse h-4 rounded w-2/3" />
          <div className="skeleton-pulse h-20 rounded w-full" />
        </div>
      ) : (
        <div
          ref={containerRef}
          className="giscus-frame"
          style={{ minHeight: "200px" }}
        >
          <div className="p-8 bg-[#0a0a0a] border border-[#262626] rounded-lg text-center">
            <p className="text-[#888888] text-[14px]">
              Giscus comments integration ready. Configure with your GitHub repository to enable comments.
            </p>
            <p className="text-[#888888] text-[12px] mt-2">
              Replace the data-repo and data-category-id attributes with your actual Giscus configuration.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
