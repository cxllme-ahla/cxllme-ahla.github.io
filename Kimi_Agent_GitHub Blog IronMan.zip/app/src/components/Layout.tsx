import { useLenisInit } from "@/hooks/useLenis";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FloatingActionButton from "@/components/FloatingActionButton";
import type { ReactNode } from "react";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  useLenisInit();

  return (
    <div className="min-h-screen bg-[#020202] text-white">
      <Navbar />
      <main>{children}</main>
      <Footer />
      <FloatingActionButton />
    </div>
  );
}
