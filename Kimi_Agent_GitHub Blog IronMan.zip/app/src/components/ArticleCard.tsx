import { Link } from "react-router-dom";
import type { BlogPost } from "@/types/blog";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

interface ArticleCardProps {
  post: BlogPost;
  index?: number;
}

export default function ArticleCard({ post, index = 0 }: ArticleCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const card = cardRef.current;
    const imgWrap = imgRef.current;
    if (!card || !imgWrap) return;

    const img = imgWrap.querySelector(".img-inner") as HTMLElement;
    if (!img) return;

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: imgWrap,
        start: "top 80%",
        toggleActions: "play none none none",
      },
      defaults: { duration: 1.4, ease: "power2.inOut" },
    });

    tl.fromTo(
      imgWrap,
      { clipPath: "inset(0% 0% 0% 0%)" },
      { clipPath: "inset(0% 0% 100% 0%)", ease: "power3.inOut" },
      0
    );

    tl.fromTo(
      img,
      { scale: 1.4, filter: "blur(15px)" },
      { scale: 1, filter: "blur(0px)", ease: "power3.inOut" },
      0
    );

    return () => {
      tl.kill();
    };
  }, []);

  return (
    <div ref={cardRef} className="group" style={{ animationDelay: `${index * 0.1}s` }}>
      <Link to={`/post/${post.slug}`} className="block">
        {/* Image */}
        <div
          ref={imgRef}
          className="relative aspect-[4/3] overflow-hidden rounded-lg mb-4"
        >
          <img
            src={post.image}
            alt={post.title}
            className="img-inner w-full h-full object-cover"
            loading="lazy"
          />
        </div>

        {/* Content */}
        <h3 className="font-serif text-[24px] md:text-[32px] font-normal text-white leading-tight group-hover:text-[#d4af37] transition-colors duration-300">
          {post.title}
        </h3>
        <p className="mt-2 text-[15px] text-[#e2e2e2] line-clamp-2 leading-relaxed">
          {post.excerpt}
        </p>
        <div className="mt-3 flex items-center gap-3 text-[12px] text-[#888888]">
          <span>{new Date(post.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
          <span>•</span>
          <span>{post.readingTime} min read</span>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {post.tags.slice(0, 3).map((tag) => (
            <span
              key={tag}
              className="text-[11px] text-[#888888] border border-[#262626] rounded px-2 py-0.5 hover:border-[#d4af37] hover:text-[#d4af37] transition-colors"
            >
              {tag}
            </span>
          ))}
        </div>
        <span className="inline-block mt-3 text-[14px] font-medium uppercase tracking-[0.02em] text-[#d4af37] opacity-0 group-hover:opacity-100 transition-opacity duration-300 link-underline">
          Read Article →
        </span>
      </Link>
    </div>
  );
}
