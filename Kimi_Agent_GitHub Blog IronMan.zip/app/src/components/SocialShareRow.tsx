import { useState } from "react";
import { Twitter, Facebook, Linkedin, Link2, Check } from "lucide-react";

interface SocialShareRowProps {
  url?: string;
  title?: string;
}

export default function SocialShareRow({
  url = typeof window !== "undefined" ? window.location.href : "",
  title = "StarkInsider Article",
}: SocialShareRowProps) {
  const [copied, setCopied] = useState(false);

  const shareUrls = {
    twitter: `https://twitter.com/intent/tweet?url=${encodeURIComponent(
      url
    )}&text=${encodeURIComponent(title)}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
      url
    )}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
      url
    )}`,
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback
      const input = document.createElement("input");
      input.value = url;
      document.body.appendChild(input);
      input.select();
      document.execCommand("copy");
      document.body.removeChild(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="flex items-center gap-3">
      <span className="text-[12px] text-[#888888] uppercase tracking-[0.04em] mr-2">
        Share:
      </span>
      <a
        href={shareUrls.twitter}
        target="_blank"
        rel="noopener noreferrer"
        className="text-[#888888] hover:text-[#d4af37] transition-colors"
        aria-label="Share on Twitter"
      >
        <Twitter size={20} />
      </a>
      <a
        href={shareUrls.facebook}
        target="_blank"
        rel="noopener noreferrer"
        className="text-[#888888] hover:text-[#d4af37] transition-colors"
        aria-label="Share on Facebook"
      >
        <Facebook size={20} />
      </a>
      <a
        href={shareUrls.linkedin}
        target="_blank"
        rel="noopener noreferrer"
        className="text-[#888888] hover:text-[#d4af37] transition-colors"
        aria-label="Share on LinkedIn"
      >
        <Linkedin size={20} />
      </a>
      <button
        onClick={handleCopy}
        className="text-[#888888] hover:text-[#d4af37] transition-colors"
        aria-label="Copy link"
      >
        {copied ? <Check size={20} /> : <Link2 size={20} />}
      </button>
      {copied && (
        <span className="text-[12px] text-[#d4af37] animate-pulse">
          Copied!
        </span>
      )}
    </div>
  );
}
