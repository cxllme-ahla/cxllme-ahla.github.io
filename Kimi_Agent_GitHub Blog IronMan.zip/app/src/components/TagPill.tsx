import { Link } from "react-router-dom";

interface TagPillProps {
  tag: string;
  active?: boolean;
  onClick?: () => void;
}

export default function TagPill({ tag, active = false, onClick }: TagPillProps) {
  if (onClick) {
    return (
      <button
        onClick={onClick}
        className={`text-[12px] border rounded px-3 py-1 transition-colors font-sans ${
          active
            ? "border-[#d4af37] text-[#d4af37]"
            : "border-[#262626] text-[#888888] hover:border-[#d4af37] hover:text-[#d4af37]"
        }`}
      >
        {tag}
      </button>
    );
  }

  return (
    <Link
      to={`/archive?tag=${encodeURIComponent(tag)}`}
      className={`text-[12px] border rounded px-3 py-1 transition-colors font-sans inline-block ${
        active
          ? "border-[#d4af37] text-[#d4af37]"
          : "border-[#262626] text-[#888888] hover:border-[#d4af37] hover:text-[#d4af37]"
      }`}
    >
      {tag}
    </Link>
  );
}
