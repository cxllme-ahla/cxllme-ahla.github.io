import { useEffect, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function ReadingProgressBar() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const article = document.getElementById("article-content");
    if (!article) return;

    const trigger = ScrollTrigger.create({
      trigger: article,
      start: "top top",
      end: "bottom bottom",
      onUpdate: (self) => {
        const bar = document.getElementById("reading-progress");
        if (bar) {
          bar.style.transform = `scaleX(${self.progress})`;
        }
      },
      onEnter: () => setVisible(true),
      onLeaveBack: () => setVisible(false),
    });

    return () => {
      trigger.kill();
    };
  }, []);

  return (
    <div
      className={`fixed top-0 left-0 right-0 z-[60] h-[2px] transition-opacity duration-300 ${
        visible ? "opacity-100" : "opacity-0"
      }`}
    >
      <div
        id="reading-progress"
        className="h-full bg-[#d4af37] origin-left"
        style={{ transform: "scaleX(0)" }}
      />
    </div>
  );
}
