import { Routes, Route } from "react-router-dom";
import { Suspense, lazy } from "react";
import Layout from "@/components/Layout";
import ScrollToTop from "@/components/ScrollToTop";

const HomePage = lazy(() => import("@/pages/HomePage"));
const PostPage = lazy(() => import("@/pages/PostPage"));
const ArchivePage = lazy(() => import("@/pages/ArchivePage"));
const AboutPage = lazy(() => import("@/pages/AboutPage"));
const ContactPage = lazy(() => import("@/pages/ContactPage"));

function App() {
  return (
    <>
      <ScrollToTop />
      <Layout>
        <Suspense
          fallback={
            <div className="min-h-screen bg-[#020202] flex items-center justify-center">
              <div className="skeleton-pulse w-32 h-8 rounded" />
            </div>
          }
        >
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/post/:slug" element={<PostPage />} />
            <Route path="/archive" element={<ArchivePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/contact" element={<ContactPage />} />
          </Routes>
        </Suspense>
      </Layout>
    </>
  );
}

export default App;
