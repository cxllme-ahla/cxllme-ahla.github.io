import type { BlogPost } from "@/types/blog";

export const posts: BlogPost[] = [
  {
    slug: "the-future-of-wearable-technology",
    title: "The Future of Wearable Technology: Beyond the Smartwatch",
    excerpt: "From health monitoring to augmented reality overlays, wearable tech is entering a new era of sophistication and integration into our daily lives.",
    content: `# The Future of Wearable Technology: Beyond the Smartwatch

Wearable technology has come a long way since the first fitness trackers. Today, we're standing at the precipice of a revolution that will fundamentally change how we interact with digital information.

## The Current Landscape

The smartwatch market has matured significantly. Devices like the Apple Watch Ultra and Samsung Galaxy Watch have transformed from novelty items into essential health monitoring tools. But this is just the beginning.

> "The next decade of wearables won't be about what you wear on your wrist. It'll be about what you wear *in* your environment."

## Emerging Form Factors

### Smart Glasses Done Right
After the Google Glass debacle, many wrote off augmented reality eyewear. But companies like Meta and Apple are proving that the concept just needed better execution. The new generation of smart glasses focuses on:

- **Audio-first experiences** — Discrete speakers and microphones
- **Subtle notifications** — No invasive screens in your field of view
- **Camera integration** — Capturing moments without pulling out your phone
- **AI assistants** — Voice-activated help that's always available

### Smart Clothing
Textiles embedded with sensors can now monitor:
- Muscle activity and fatigue levels
- Posture and movement patterns
- Body temperature and hydration
- Respiratory rate and depth

\`\`\`python
# Example: Reading biometric data from smart clothing
class SmartShirt:
    def __init__(self):
        self.sensors = {
            'heart_rate': HRSensor(),
            'respiration': RespirationSensor(),
            'temperature': TempSensor(),
            'motion': IMUSensor()
        }

    def get_health_snapshot(self):
        return {
            name: sensor.read()
            for name, sensor in self.sensors.items()
        }
\`\`\`

## Health Revolution

The most compelling use case for wearables remains health monitoring. Modern devices can detect:

| Condition | Detection Method | Accuracy |
|-----------|-----------------|-----------|
| Atrial Fibrillation | PPG + ECG | 98.5% |
| Sleep Apnea | Blood oxygen + movement | 90% |
| Diabetes (risk) | Glucose monitoring | 85% |
| Falls | Accelerometer + gyroscope | 99% |

## The Privacy Question

With great data comes great responsibility. The amount of personal health information collected by wearables raises serious privacy concerns. Who owns this data? How is it being used? These are questions that the industry must address proactively.

## Looking Ahead

The future of wearables isn't about individual devices — it's about an ecosystem of interconnected sensors that work together to create a comprehensive picture of your health, productivity, and environment.

As we move toward this future, the line between technology and biology will continue to blur. The question isn't whether we'll adopt these technologies, but how we'll manage their impact on our lives.`,
    image: "/images/featured-post.jpg",
    category: "Technology",
    tags: ["wearables", "smartwatch", "health-tech", "AR", "future"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-06-25",
    readingTime: 8,
    featured: true,
  },
  {
    slug: "next-gen-gaming-controllers",
    title: "Next-Gen Gaming Controllers: Haptics and Beyond",
    excerpt: "The evolution of game controllers from simple joysticks to haptic feedback masterpieces that immerse players like never before.",
    content: `# Next-Gen Gaming Controllers

Gaming controllers have undergone a remarkable transformation. What started as simple joysticks with a single button has evolved into sophisticated haptic devices that can simulate everything from raindrops to heartbeats.

## The Haptic Revolution

Sony's DualSense controller for the PlayStation 5 marked a turning point. Its adaptive triggers and advanced haptic feedback create physical sensations that match in-game actions. Drawing a bow feels tense. Driving on gravel feels gritty.

## What's Next?

The future promises even more immersive feedback:
- Temperature variation
- Texture simulation
- Resistance-based triggers
- Biometric integration`,
    image: "/images/post-1.jpg",
    category: "Gaming",
    tags: ["gaming", "controllers", "haptics", "playstation", "xbox"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-06-22",
    readingTime: 5,
  },
  {
    slug: "vr-ar-revolution-2025",
    title: "The VR/AR Revolution: Where We Stand in 2025",
    excerpt: "Virtual and augmented reality technologies are finally delivering on their decade-old promises. Here's the state of immersive tech.",
    content: `# The VR/AR Revolution: Where We Stand in 2025

After years of false starts and overpromises, VR and AR are finding their footing. The technology has matured, prices have dropped, and most importantly, the content has improved dramatically.

## Standalone VR is Here

Gone are the days of needing a powerful gaming PC and a mess of cables. Devices like the Meta Quest 3 and Apple Vision Pro offer compelling experiences without tethering you to a computer.

## Mixed Reality

The boundary between virtual and physical is blurring. Passthrough cameras allow virtual objects to exist in your real environment, creating genuinely new ways to work, play, and create.`,
    image: "/images/post-2.jpg",
    category: "Technology",
    tags: ["VR", "AR", "mixed-reality", "meta-quest", "apple"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-06-18",
    readingTime: 6,
  },
  {
    slug: "developer-workflow-2025",
    title: "The Modern Developer's Workflow in 2025",
    excerpt: "How AI-assisted coding, cloud environments, and new paradigms are reshaping the way software developers work.",
    content: `# The Modern Developer's Workflow in 2025

Software development looks very different today than it did just five years ago. AI assistants, cloud-native tools, and new methodologies have transformed how we build and ship code.

## AI Pair Programming

Tools like GitHub Copilot and Cursor have become indispensable. They're not replacing developers — they're amplifying our capabilities, handling boilerplate, and suggesting solutions we might not have considered.

## The Cloud Development Environment

Local development environments are becoming optional. With GitHub Codespaces, Gitpod, and similar services, you can spin up a fully configured development environment in seconds from any device.`,
    image: "/images/post-3.jpg",
    category: "Technology",
    tags: ["development", "AI", "coding", "workflow", "productivity"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-06-15",
    readingTime: 7,
  },
  {
    slug: "cinematography-evolution",
    title: "The Evolution of Digital Cinematography",
    excerpt: "How digital cameras have transformed filmmaking, from the first 4K sensors to today's AI-enhanced computational cinematography.",
    content: `# The Evolution of Digital Cinematography

Digital cinematography has come a long way since the first 1080p cameras. Today's digital cinema cameras can capture images that rival and sometimes surpass traditional film.

## The Resolution Race

We've moved from 1080p to 4K to 8K and beyond. But resolution is just one part of the story. Dynamic range, color science, and low-light performance matter just as much — if not more.

## Computational Cinematography

AI is entering the camera. Real-time noise reduction, intelligent autofocus, and even automated framing assistance are becoming standard features in professional cameras.`,
    image: "/images/post-4.jpg",
    category: "Cinema",
    tags: ["cinema", "cameras", "filmmaking", "digital", "AI"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-06-10",
    readingTime: 6,
  },
  {
    slug: "electric-vehicles-future",
    title: "Electric Vehicles: The Road Ahead",
    excerpt: "Beyond Tesla: How the EV landscape is diversifying with new players, better batteries, and charging infrastructure that's finally keeping pace.",
    content: `# Electric Vehicles: The Road Ahead

The electric vehicle market is entering its second act. The early adopters have adopted, and now the technology needs to prove itself to mainstream consumers.

## Beyond Range Anxiety

Modern EVs routinely offer 300+ miles of range. The conversation has shifted from "will I make it?" to "where will I charge?" — and charging infrastructure is expanding rapidly.

## New Players, New Ideas

Traditional automakers are finally getting serious about EVs, while newcomers like Rivian and Lucid are pushing the boundaries of what an electric vehicle can be.`,
    image: "/images/post-5.jpg",
    category: "Technology",
    tags: ["EV", "electric-vehicles", "tesla", "automotive", "green-tech"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-06-05",
    readingTime: 5,
  },
  {
    slug: "ai-revolution-machine-learning",
    title: "The AI Revolution: Understanding Machine Learning",
    excerpt: "A deep dive into how machine learning works, from neural networks to large language models, and what it means for the future.",
    content: `# The AI Revolution: Understanding Machine Learning

Machine learning has gone from an academic curiosity to the driving force behind some of the most impactful technologies of our time. Understanding how it works is no longer optional for anyone in tech.

## Neural Networks Explained

At their core, neural networks are pattern recognition systems. They're inspired by the human brain but operate on fundamentally different principles. The magic happens in the training process.

## Large Language Models

LLMs like GPT-4 represent a paradigm shift. They're not just better at natural language processing — they demonstrate emergent capabilities that weren't explicitly programmed.`,
    image: "/images/post-6.jpg",
    category: "Technology",
    tags: ["AI", "machine-learning", "neural-networks", "LLM", "GPT"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-06-01",
    readingTime: 9,
  },
  {
    slug: "indie-game-development",
    title: "The Renaissance of Indie Game Development",
    excerpt: "How small studios are creating some of the most innovative and emotionally resonant games in the industry.",
    content: `# The Renaissance of Indie Game Development

Independent game development has never been more vibrant. With accessible tools and digital distribution, small teams are creating experiences that rival AAA productions in creativity and emotional impact.

## Tools of the Trade

Unity, Unreal Engine, Godot — modern game engines have democratized game development. A solo developer can now create something that would have required a team of fifty just a decade ago.

## Story Over Spectacle

Indie games often prioritize narrative and emotional resonance over graphical fidelity. Games like Hades, Celeste, and Hollow Knight prove that great gameplay and storytelling don't require massive budgets.`,
    image: "/images/post-1.jpg",
    category: "Gaming",
    tags: ["indie-games", "gamedev", "unity", "narrative", "creativity"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-05-28",
    readingTime: 6,
  },
  {
    slug: "streaming-wars-2025",
    title: "The Streaming Wars: Who's Winning in 2025?",
    excerpt: "The landscape of streaming services has consolidated. Here's our analysis of who's thriving and who's struggling.",
    content: `# The Streaming Wars: Who's Winning in 2025?

The streaming market has matured. The gold rush is over, and now it's about sustainable business models. Some services are thriving, others are consolidating or shutting down.

## The Winners

Netflix remains the king, but faces increasing competition. Disney+ has found its footing with a focused content strategy. HBO Max (now just Max) continues to deliver prestige television.

## The Pivot to Profitability

After years of chasing subscriber growth at any cost, streaming services are finally focusing on profitability. This means price increases, ad-supported tiers, and crackdowns on password sharing.`,
    image: "/images/post-4.jpg",
    category: "Culture",
    tags: ["streaming", "netflix", "disney", "entertainment", "media"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-05-22",
    readingTime: 5,
  },
  {
    slug: "cybersecurity-threats",
    title: "Cybersecurity Threats Every User Should Know",
    excerpt: "From phishing to ransomware, the threat landscape is evolving. Here's how to protect yourself in an increasingly hostile digital environment.",
    content: `# Cybersecurity Threats Every User Should Know

Cybersecurity isn't just for IT professionals anymore. Every person who uses the internet needs to understand the basics of digital self-defense.

## The Threat Landscape

Ransomware attacks are up 150% year over year. Phishing campaigns are becoming increasingly sophisticated. And state-sponsored attacks are targeting critical infrastructure.

## Personal Protection

The basics remain the same: use strong unique passwords, enable two-factor authentication, keep your software updated, and think before you click. But the tools available to help have improved dramatically.`,
    image: "/images/post-3.jpg",
    category: "Technology",
    tags: ["cybersecurity", "privacy", "ransomware", "phishing", "protection"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-05-18",
    readingTime: 7,
  },
  {
    slug: "smart-home-automation",
    title: "Smart Home Automation: Beyond the Hype",
    excerpt: "A realistic look at what smart home technology can and cannot do, and how to build a system that actually works.",
    content: `# Smart Home Automation: Beyond the Hype

Smart home technology promises a Jetsons-like future but often delivers frustration. Here's how to approach home automation realistically.

## What Actually Works

Smart lighting, thermostats, and door locks are genuinely useful. Voice assistants have improved dramatically. But the promise of a fully automated home remains elusive.

## The Interoperability Problem

The biggest challenge in smart homes isn't the technology — it's getting different devices to work together. Matter protocol is helping, but we're not there yet.`,
    image: "/images/post-5.jpg",
    category: "Technology",
    tags: ["smart-home", "automation", "IoT", "matter", "home-tech"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-05-12",
    readingTime: 6,
  },
  {
    slug: "documentary-filmmaking",
    title: "The Art of Documentary Filmmaking in the Digital Age",
    excerpt: "How streaming platforms and new technology are transforming documentary filmmaking and distribution.",
    content: `# The Art of Documentary Filmmaking in the Digital Age

Documentary filmmaking has undergone a renaissance. Streaming platforms have created insatiable demand for non-fiction content, and new technology has made production more accessible than ever.

## The Streaming Effect

Netflix, HBO, and Apple TV+ are investing heavily in documentaries. This funding has enabled filmmakers to tackle ambitious subjects with cinematic production values.

## New Tools, New Stories

Lightweight 4K cameras, drone cinematography, and AI-assisted editing have lowered the barrier to entry. The result is a diversity of voices and perspectives that was previously impossible.`,
    image: "/images/post-2.jpg",
    category: "Cinema",
    tags: ["documentary", "filmmaking", "streaming", "netflix", "HBO"],
    author: "Marcus Steele",
    authorAvatar: "/images/avatar.jpg",
    date: "2025-05-08",
    readingTime: 5,
  },
];

export const categories = ["All", "Technology", "Gaming", "Cinema", "Culture"];

export const allTags = Array.from(
  new Set(posts.flatMap((p) => p.tags))
).sort();

export function getPostBySlug(slug: string): BlogPost | undefined {
  return posts.find((p) => p.slug === slug);
}

export function getRelatedPosts(
  post: BlogPost,
  count: number = 3
): BlogPost[] {
  return posts
    .filter(
      (p) =>
        p.slug !== post.slug &&
        (p.category === post.category ||
          p.tags.some((t) => post.tags.includes(t)))
    )
    .slice(0, count);
}

export function getFeaturedPost(): BlogPost | undefined {
  return posts.find((p) => p.featured);
}

export function getPostsByCategory(category: string): BlogPost[] {
  if (category === "All") return posts;
  return posts.filter((p) => p.category === category);
}

export function getPostsByTag(tag: string): BlogPost[] {
  return posts.filter((p) => p.tags.includes(tag));
}

export function searchPosts(query: string): BlogPost[] {
  const q = query.toLowerCase();
  return posts.filter(
    (p) =>
      p.title.toLowerCase().includes(q) ||
      p.excerpt.toLowerCase().includes(q) ||
      p.tags.some((t) => t.toLowerCase().includes(q)) ||
      p.category.toLowerCase().includes(q)
  );
}
