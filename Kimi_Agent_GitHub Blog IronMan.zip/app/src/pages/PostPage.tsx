import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect, useMemo } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { vscDarkPlus } from "react-syntax-highlighter/dist/esm/styles/prism";
import { getPostBySlug, getRelatedPosts, posts } from "@/data/posts";
import ReadingProgressBar from "@/components/ReadingProgressBar";
import Breadcrumb from "@/components/Breadcrumb";
import SocialShareRow from "@/components/SocialShareRow";
import TagPill from "@/components/TagPill";
import GiscusComments from "@/components/GiscusComments";
import ArticleCard from "@/components/ArticleCard";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { ArrowLeft, ArrowRight } from "lucide-react";

export default function PostPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const post = getPostBySlug(slug || "");
  const headerRef = useScrollReveal<HTMLDivElement>();
  const contentRef = useScrollReveal<HTMLDivElement>();

  const relatedPosts = useMemo(() => {
    if (!post) return [];
    return getRelatedPosts(post, 3);
  }, [post]);

  const currentIndex = useMemo(() => {
    if (!post) return -1;
    return posts.findIndex((p) => p.slug === post.slug);
  }, [post]);

  const prevPost = currentIndex > 0 ? posts[currentIndex - 1] : null;
  const nextPost =
    currentIndex < posts.length - 1 ? posts[currentIndex + 1] : null;

  useEffect(() => {
    if (!post) {
      navigate("/");
    }
  }, [post, navigate]);

  if (!post) return null;

  const breadcrumbItems = [
    { label: "Home", path: "/" },
    { label: post.category, path: `/archive?category=${encodeURIComponent(post.category)}` },
    { label: post.title },
  ];

  return (
    <>
      <ReadingProgressBar />
      <article className="max-w-[1440px] mx-auto px-[clamp(20px,4vw,40px)] pt-8 pb-[120px]">
        {/* Breadcrumb */}
        <Breadcrumb items={breadcrumbItems} />

        {/* Article Header */}
        <div ref={headerRef} className="mt-8 max-w-[900px]">
          <h1 className="font-serif text-[36px] md:text-[56px] font-normal text-white leading-[1.1]">
            {post.title}
          </h1>

          {/* Metadata */}
          <div className="mt-6 flex flex-wrap items-center gap-4">
            <img
              src={post.authorAvatar}
              alt={post.author}
              className="w-8 h-8 rounded-full object-cover"
            />
            <span className="text-[14px] text-white font-sans">
              {post.author}
            </span>
            <span className="text-[#888888]">•</span>
            <span className="text-[14px] text-[#888888] font-sans">
              {new Date(post.date).toLocaleDateString("en-US", {
                month: "long",
                day: "numeric",
                year: "numeric",
              })}
            </span>
            <span className="text-[#888888]">•</span>
            <span className="text-[14px] text-[#888888] font-sans">
              {post.readingTime} min read
            </span>
            <span className="text-[#888888]">•</span>
            <Link
              to={`/archive?category=${encodeURIComponent(post.category)}`}
              className="text-[14px] text-[#d4af37] font-sans hover:underline"
            >
              {post.category}
            </Link>
          </div>

          {/* Social Share */}
          <div className="mt-6">
            <SocialShareRow title={post.title} />
          </div>
        </div>

        {/* Featured Image */}
        <div className="mt-10 max-w-[1100px]">
          <img
            src={post.image}
            alt={post.title}
            className="w-full rounded-lg object-cover aspect-video"
          />
        </div>

        {/* Article Body */}
        <div
          id="article-content"
          ref={contentRef}
          className="mt-12 max-w-[720px] mx-auto prose-custom"
        >
          <ReactMarkdown
            remarkPlugins={[remarkGfm]}
            components={{
              code({ className, children, ...props }) {
                const match = /language-(\w+)/.exec(className || "");
                return match ? (
                  <SyntaxHighlighter
                    style={vscDarkPlus}
                    language={match[1]}
                    PreTag="div"
                  >
                    {String(children).replace(/\n$/, "")}
                  </SyntaxHighlighter>
                ) : (
                  <code className={className} {...props}>
                    {children}
                  </code>
                );
              },
            }}
          >
            {post.content}
          </ReactMarkdown>
        </div>

        {/* Tags */}
        <div className="mt-12 max-w-[720px] mx-auto">
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-[14px] text-[#888888] font-sans">Tags:</span>
            {post.tags.map((tag) => (
              <TagPill key={tag} tag={tag} />
            ))}
          </div>
        </div>

        {/* Giscus Comments */}
        <div className="max-w-[720px] mx-auto">
          <GiscusComments />
        </div>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="mt-16 pt-8 border-t border-[#262626] max-w-[1440px]">
            <h2 className="font-serif text-[32px] text-white mb-8">
              You Might Also Like
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {relatedPosts.map((rp) => (
                <ArticleCard key={rp.slug} post={rp} />
              ))}
            </div>
          </div>
        )}

        {/* Post Navigation */}
        <div className="mt-16 pt-8 border-t border-[#262626] max-w-[720px] mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {prevPost ? (
              <Link
                to={`/post/${prevPost.slug}`}
                className="group p-4 border border-[#262626] rounded-lg hover:border-[#d4af37] transition-colors"
              >
                <span className="text-[12px] text-[#888888] font-sans flex items-center gap-1">
                  <ArrowLeft size={14} /> Previous
                </span>
                <p className="font-serif text-[20px] text-white mt-2 group-hover:text-[#d4af37] transition-colors leading-tight">
                  {prevPost.title}
                </p>
              </Link>
            ) : (
              <div />
            )}
            {nextPost ? (
              <Link
                to={`/post/${nextPost.slug}`}
                className="group p-4 border border-[#262626] rounded-lg hover:border-[#d4af37] transition-colors text-right"
              >
                <span className="text-[12px] text-[#888888] font-sans flex items-center gap-1 justify-end">
                  Next <ArrowRight size={14} />
                </span>
                <p className="font-serif text-[20px] text-white mt-2 group-hover:text-[#d4af37] transition-colors leading-tight">
                  {nextPost.title}
                </p>
              </Link>
            ) : (
              <div />
            )}
          </div>
        </div>
      </article>
    </>
  );
}
