import { useState } from "react";
import { Link } from "react-router-dom";
import { posts, getFeaturedPost } from "@/data/posts";
import HeroWebGL from "@/components/HeroWebGL";
import ArticleCard from "@/components/ArticleCard";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { ChevronDown } from "lucide-react";

export default function HomePage() {
  const featuredPost = getFeaturedPost();
  const [visibleCount, setVisibleCount] = useState(6);
  const featuredRef = useScrollReveal<HTMLDivElement>();
  const gridRef = useScrollReveal<HTMLDivElement>();

  const latestPosts = posts.filter((p) => !p.featured);
  const visiblePosts = latestPosts.slice(0, visibleCount);
  const hasMore = visibleCount < latestPosts.length;

  const handleLoadMore = () => {
    setVisibleCount((prev) => Math.min(prev + 6, latestPosts.length));
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen bg-[#020202] overflow-hidden">
        <HeroWebGL />
        <div
          className="relative z-10 h-full flex flex-col items-center justify-center pointer-events-none"
          style={{ marginTop: "-60px" }}
        >
          <p className="font-sans text-[12px] uppercase tracking-[0.1em] text-[#888888] mt-[40vh]">
            CULTURE • TECHNOLOGY • CINEMA
          </p>
        </div>
        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2">
          <div className="w-[1px] h-12 bg-[#262626] relative overflow-hidden">
            <div
              className="absolute top-0 left-0 w-full bg-[#d4af37]"
              style={{
                height: "40%",
                animation: "scroll-pulse 2s ease-in-out infinite",
              }}
            />
          </div>
          <ChevronDown size={16} className="text-[#888888] animate-bounce" />
        </div>
      </section>

      {/* Featured Post */}
      {featuredPost && (
        <section
          ref={featuredRef}
          className="max-w-[1440px] mx-auto px-[clamp(20px,4vw,40px)] pt-[120px]"
        >
          <Link to={`/post/${featuredPost.slug}`} className="block group">
            {/* Full-width image */}
            <div className="relative aspect-video overflow-hidden rounded-lg">
              <img
                src={featuredPost.image}
                alt={featuredPost.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
            </div>
            {/* Text - 60% width */}
            <div className="mt-8 w-full lg:w-[60%]">
              <div className="flex items-center gap-3 text-[12px] text-[#888888] mb-4">
                <span>{featuredPost.author}</span>
                <span>•</span>
                <span>
                  {new Date(featuredPost.date).toLocaleDateString("en-US", {
                    month: "long",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
                <span>•</span>
                <span>{featuredPost.readingTime} min read</span>
              </div>
              <h2 className="font-serif text-[36px] md:text-[56px] font-normal text-white leading-[1.1] group-hover:text-[#d4af37] transition-colors">
                {featuredPost.title}
              </h2>
              <p className="mt-4 text-[18px] text-[#e2e2e2] leading-relaxed line-clamp-3">
                {featuredPost.excerpt}
              </p>
              <span className="inline-block mt-4 text-[14px] font-medium uppercase tracking-[0.02em] text-[#d4af37] link-underline">
                Read Article →
              </span>
            </div>
          </Link>
        </section>
      )}

      {/* Latest Posts Grid */}
      <section className="max-w-[1440px] mx-auto px-[clamp(20px,4vw,40px)] pt-[120px] pb-[60px]">
        <div
          ref={gridRef}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {visiblePosts.map((post, i) => (
            <div
              key={post.slug}
              className={
                i % 3 !== 2 ? "lg:border-r lg:border-[#262626] lg:pr-8" : ""
              }
            >
              <ArticleCard post={post} index={i} />
            </div>
          ))}
        </div>

        {/* Load More */}
        <div className="flex justify-center mt-16">
          <button
            onClick={handleLoadMore}
            disabled={!hasMore}
            className={`px-8 py-3 border border-[#262626] font-sans text-[14px] font-medium uppercase tracking-[0.02em] transition-all duration-300 ${
              hasMore
                ? "text-white hover:bg-[#0a0a0a] cursor-pointer"
                : "text-[#888888] cursor-default opacity-50"
            }`}
          >
            {hasMore ? "Load More" : "No More Posts"}
          </button>
        </div>
      </section>
    </div>
  );
}
