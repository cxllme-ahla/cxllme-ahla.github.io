import { useState } from "react";
import { Twitter, Github, Linkedin, Mail, Check } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const headerRef = useScrollReveal<HTMLDivElement>();
  const formRef = useScrollReveal<HTMLDivElement>();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you'd send this to a backend
    setSubmitted(true);
  };

  return (
    <div className="max-w-[1440px] mx-auto px-[clamp(20px,4vw,40px)] pt-[60px] pb-[120px]">
      {/* Header */}
      <div ref={headerRef}>
        <h1 className="font-serif text-[56px] text-white">Contact</h1>
        <p className="mt-2 text-[18px] text-[#888888] font-sans">
          Get in touch.
        </p>
      </div>

      {/* Contact Form */}
      <div ref={formRef} className="mt-12 max-w-[600px] mx-auto">
        {submitted ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 mx-auto rounded-full bg-[#0a0a0a] border border-[#d4af37] flex items-center justify-center">
              <Check size={32} className="text-[#d4af37]" />
            </div>
            <h2 className="font-serif text-[24px] text-[#d4af37] mt-6">
              Message sent!
            </h2>
            <p className="text-[14px] text-[#888888] mt-2 font-sans">
              Thank you for reaching out. We'll get back to you soon.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-6">
            <div>
              <label
                htmlFor="name"
                className="block text-[14px] text-[#888888] mb-2 font-sans"
              >
                Name
              </label>
              <input
                type="text"
                id="name"
                required
                value={formData.name}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, name: e.target.value }))
                }
                className="w-full bg-[#0a0a0a] border border-[#262626] text-white text-[16px] font-sans px-4 py-3 rounded outline-none focus:border-[#d4af37] transition-colors"
                placeholder="Your name"
              />
            </div>
            <div>
              <label
                htmlFor="email"
                className="block text-[14px] text-[#888888] mb-2 font-sans"
              >
                Email
              </label>
              <input
                type="email"
                id="email"
                required
                value={formData.email}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, email: e.target.value }))
                }
                className="w-full bg-[#0a0a0a] border border-[#262626] text-white text-[16px] font-sans px-4 py-3 rounded outline-none focus:border-[#d4af37] transition-colors"
                placeholder="your@email.com"
              />
            </div>
            <div>
              <label
                htmlFor="message"
                className="block text-[14px] text-[#888888] mb-2 font-sans"
              >
                Message
              </label>
              <textarea
                id="message"
                required
                rows={6}
                value={formData.message}
                onChange={(e) =>
                  setFormData((prev) => ({ ...prev, message: e.target.value }))
                }
                className="w-full bg-[#0a0a0a] border border-[#262626] text-white text-[16px] font-sans px-4 py-3 rounded outline-none focus:border-[#d4af37] transition-colors resize-none"
                placeholder="Your message..."
              />
            </div>
            <button
              type="submit"
              className="w-full bg-[#d4af37] text-[#020202] font-sans text-[14px] font-semibold uppercase tracking-[0.02em] py-3 rounded hover:brightness-110 transition-all"
            >
              Send Message
            </button>
          </form>
        )}

        {/* Alternative Contact */}
        <div className="mt-12 pt-8 border-t border-[#262626]">
          <p className="text-[14px] text-[#888888] font-sans">
            Or reach out directly:
          </p>
          <a
            href="mailto:hello@starkinsider.com"
            className="inline-flex items-center gap-2 mt-3 text-[#d4af37] hover:underline font-sans"
          >
            <Mail size={16} />
            hello@starkinsider.com
          </a>
          <div className="flex items-center gap-4 mt-4">
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#888888] hover:text-[#d4af37] transition-colors"
              aria-label="Twitter"
            >
              <Twitter size={20} />
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#888888] hover:text-[#d4af37] transition-colors"
              aria-label="GitHub"
            >
              <Github size={20} />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#888888] hover:text-[#d4af37] transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin size={20} />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
