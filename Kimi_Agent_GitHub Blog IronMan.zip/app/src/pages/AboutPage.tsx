import { Twitter, Github, Linkedin } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";

export default function AboutPage() {
  const headerRef = useScrollReveal<HTMLDivElement>();
  const contentRef = useScrollReveal<HTMLDivElement>();
  const statsRef = useScrollReveal<HTMLDivElement>();

  return (
    <div className="max-w-[1440px] mx-auto px-[clamp(20px,4vw,40px)] pt-[60px] pb-[120px]">
      {/* Header */}
      <div ref={headerRef}>
        <h1 className="font-serif text-[56px] text-white">About</h1>
        <p className="mt-2 text-[18px] text-[#888888] font-sans">
          The story behind StarkInsider.
        </p>
      </div>

      {/* Profile */}
      <div ref={contentRef} className="mt-16 max-w-[720px] mx-auto text-center">
        <div className="w-[200px] h-[200px] mx-auto rounded-full overflow-hidden border-2 border-[#262626]">
          <img
            src="/images/avatar.jpg"
            alt="Marcus Steele"
            className="w-full h-full object-cover"
          />
        </div>
        <h2 className="font-serif text-[32px] text-white mt-6">
          Marcus Steele
        </h2>
        <p className="text-[14px] text-[#888888] mt-1 font-sans">
          Founder & Editor-in-Chief
        </p>

        {/* Bio */}
        <div className="mt-8 text-left">
          <p className="text-[18px] text-[#e2e2e2] leading-[1.8] font-sans">
            StarkInsider was born from a simple belief: that technology, culture,
            and cinema are not separate worlds, but interconnected threads of
            human creativity and innovation. Founded in 2022, this platform has
            grown into a destination for readers who crave depth, analysis, and
            storytelling that goes beyond the surface.
          </p>
          <p className="text-[18px] text-[#e2e2e2] leading-[1.8] font-sans mt-6">
            With a background spanning software engineering, film criticism, and
            digital media, I bring a multidisciplinary perspective to every
            article. Whether we're dissecting the latest AI breakthrough,
            reviewing a groundbreaking indie film, or exploring the intersection
            of gaming and storytelling, the goal remains the same: to inform,
            challenge, and inspire.
          </p>
          <p className="text-[18px] text-[#e2e2e2] leading-[1.8] font-sans mt-6">
            StarkInsider is more than a blog — it's a community of curious
            minds. Join us as we explore the cutting edge of technology, the
            artistry of cinema, and the culture that shapes our digital age.
          </p>
        </div>

        {/* Social Links */}
        <div className="mt-8 flex items-center justify-center gap-6">
          <a
            href="https://twitter.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#888888] hover:text-[#d4af37] transition-colors"
            aria-label="Twitter"
          >
            <Twitter size={24} />
          </a>
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#888888] hover:text-[#d4af37] transition-colors"
            aria-label="GitHub"
          >
            <Github size={24} />
          </a>
          <a
            href="https://linkedin.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#888888] hover:text-[#d4af37] transition-colors"
            aria-label="LinkedIn"
          >
            <Linkedin size={24} />
          </a>
        </div>
      </div>

      {/* Stats */}
      <div
        ref={statsRef}
        className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-[800px] mx-auto"
      >
        {[
          { number: "47", label: "Articles Published" },
          { number: "3", label: "Years of Writing" },
          { number: "12K", label: "Monthly Readers" },
        ].map((stat, i) => (
          <div
            key={stat.label}
            className={`text-center py-8 ${
              i < 2 ? "md:border-r md:border-[#262626]" : ""
            }`}
          >
            <div className="font-serif text-[48px] text-[#d4af37]">
              {stat.number}
            </div>
            <div className="text-[14px] text-[#888888] font-sans mt-1">
              {stat.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
