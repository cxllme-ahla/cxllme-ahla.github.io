import { useState, useMemo, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { posts, categories, allTags, getPostsByCategory } from "@/data/posts";
import ArticleCard from "@/components/ArticleCard";
import SkeletonLoader from "@/components/SkeletonLoader";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { Grid3X3, List, ChevronLeft, ChevronRight, Search } from "lucide-react";

const ITEMS_PER_PAGE = 9;

export default function ArchivePage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [sortOrder, setSortOrder] = useState<"newest" | "oldest">("newest");

  const urlCategory = searchParams.get("category") || "All";
  const urlTag = searchParams.get("tag") || "";

  const headerRef = useScrollReveal<HTMLDivElement>();

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    setCurrentPage(1);
  }, [urlCategory, urlTag, sortOrder]);

  const filteredPosts = useMemo(() => {
    let result = posts;

    if (urlCategory && urlCategory !== "All") {
      result = getPostsByCategory(urlCategory);
    }

    if (urlTag) {
      result = result.filter((p) => p.tags.includes(urlTag));
    }

    if (sortOrder === "oldest") {
      result = [...result].reverse();
    }

    return result;
  }, [urlCategory, urlTag, sortOrder]);

  const totalPages = Math.ceil(filteredPosts.length / ITEMS_PER_PAGE);
  const paginatedPosts = filteredPosts.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const handleCategoryChange = (category: string) => {
    const params = new URLSearchParams(searchParams);
    if (category === "All") {
      params.delete("category");
    } else {
      params.set("category", category);
    }
    setSearchParams(params);
  };

  const handleTagChange = (tag: string) => {
    const params = new URLSearchParams(searchParams);
    if (tag === urlTag) {
      params.delete("tag");
    } else {
      params.set("tag", tag);
    }
    setSearchParams(params);
  };

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    const maxVisible = 5;

    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      pages.push(1);
      if (currentPage > 3) pages.push("...");
      const start = Math.max(2, currentPage - 1);
      const end = Math.min(totalPages - 1, currentPage + 1);
      for (let i = start; i <= end; i++) pages.push(i);
      if (currentPage < totalPages - 2) pages.push("...");
      pages.push(totalPages);
    }
    return pages;
  };

  return (
    <div className="max-w-[1440px] mx-auto px-[clamp(20px,4vw,40px)] pt-[60px] pb-[120px]">
      {/* Header */}
      <div ref={headerRef}>
        <h1 className="font-serif text-[56px] text-white">Archive</h1>
        <p className="mt-2 text-[18px] text-[#888888] font-sans">
          All articles, organized by date, category, and tag.
        </p>
        <p className="mt-2 text-[14px] text-[#888888] font-sans">
          {filteredPosts.length} article{filteredPosts.length !== 1 ? "s" : ""}
        </p>
      </div>

      {/* Filter Bar */}
      <div className="sticky top-[60px] z-30 mt-8 py-4 bg-[rgba(2,2,2,0.9)] backdrop-blur-[12px] border-y border-[#262626]">
        <div className="flex flex-wrap items-center gap-4">
          {/* Category Dropdown */}
          <select
            value={urlCategory}
            onChange={(e) => handleCategoryChange(e.target.value)}
            className="bg-[#0a0a0a] border border-[#262626] text-white text-[14px] font-sans px-3 py-2 rounded outline-none focus:border-[#d4af37] transition-colors"
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>

          {/* Tag Filter */}
          <div className="flex items-center gap-2 overflow-x-auto flex-1">
            <span className="text-[12px] text-[#888888] font-sans whitespace-nowrap">
              Tags:
            </span>
            {allTags.slice(0, 12).map((tag) => (
              <button
                key={tag}
                onClick={() => handleTagChange(tag)}
                className={`text-[12px] border rounded px-2 py-1 whitespace-nowrap transition-colors font-sans ${
                  urlTag === tag
                    ? "border-[#d4af37] text-[#d4af37]"
                    : "border-[#262626] text-[#888888] hover:border-[#d4af37] hover:text-[#d4af37]"
                }`}
              >
                {tag}
              </button>
            ))}
          </div>

          {/* Sort */}
          <button
            onClick={() =>
              setSortOrder((prev) => (prev === "newest" ? "oldest" : "newest"))
            }
            className="text-[14px] text-[#888888] hover:text-white transition-colors font-sans whitespace-nowrap"
          >
            {sortOrder === "newest" ? "Newest First" : "Oldest First"}
          </button>

          {/* View Toggle */}
          <div className="flex items-center border border-[#262626] rounded overflow-hidden">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-2 transition-colors ${
                viewMode === "grid"
                  ? "bg-[#0a0a0a] text-white"
                  : "text-[#888888] hover:text-white"
              }`}
              aria-label="Grid view"
            >
              <Grid3X3 size={16} />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-2 transition-colors ${
                viewMode === "list"
                  ? "bg-[#0a0a0a] text-white"
                  : "text-[#888888] hover:text-white"
              }`}
              aria-label="List view"
            >
              <List size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      {loading ? (
        <div className="mt-8">
          <SkeletonLoader count={9} />
        </div>
      ) : filteredPosts.length === 0 ? (
        <div className="mt-16 flex flex-col items-center text-center">
          <Search size={48} className="text-[#888888] mb-4" />
          <h2 className="font-serif text-[24px] text-white">
            No articles found.
          </h2>
          <p className="text-[14px] text-[#888888] mt-2">
            Try adjusting your filters.
          </p>
        </div>
      ) : viewMode === "grid" ? (
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {paginatedPosts.map((post, i) => (
            <ArticleCard key={post.slug} post={post} index={i} />
          ))}
        </div>
      ) : (
        <div className="mt-8 flex flex-col">
          {paginatedPosts.map((post) => (
            <a
              key={post.slug}
              href={`/post/${post.slug}`}
              onClick={(e) => {
                e.preventDefault();
                window.location.href = `/post/${post.slug}`;
              }}
              className="flex gap-6 py-6 border-b border-[#262626] hover:bg-[#0a0a0a] transition-colors group"
            >
              <div className="w-[200px] flex-shrink-0 aspect-video overflow-hidden rounded-lg">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-serif text-[20px] text-white group-hover:text-[#d4af37] transition-colors leading-tight">
                  {post.title}
                </h3>
                <p className="mt-2 text-[14px] text-[#e2e2e2] line-clamp-2">
                  {post.excerpt}
                </p>
                <div className="mt-2 flex items-center gap-3 text-[12px] text-[#888888]">
                  <span>
                    {new Date(post.date).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </span>
                  <span>•</span>
                  <span>{post.readingTime} min read</span>
                </div>
              </div>
            </a>
          ))}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && !loading && (
        <div className="flex items-center justify-center gap-2 mt-12">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className={`flex items-center gap-1 px-3 py-2 text-[14px] font-sans transition-colors ${
              currentPage === 1
                ? "text-[#888888] opacity-50 cursor-default"
                : "text-white hover:text-[#d4af37]"
            }`}
          >
            <ChevronLeft size={16} /> Previous
          </button>

          {getPageNumbers().map((page, i) =>
            page === "..." ? (
              <span key={`ellipsis-${i}`} className="text-[#888888] px-2">
                ...
              </span>
            ) : (
              <button
                key={page}
                onClick={() => setCurrentPage(page as number)}
                className={`w-10 h-10 rounded text-[14px] font-sans transition-colors ${
                  currentPage === page
                    ? "border border-[#d4af37] text-white"
                    : "text-[#888888] hover:text-white"
                }`}
              >
                {page}
              </button>
            )
          )}

          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className={`flex items-center gap-1 px-3 py-2 text-[14px] font-sans transition-colors ${
              currentPage === totalPages
                ? "text-[#888888] opacity-50 cursor-default"
                : "text-white hover:text-[#d4af37]"
            }`}
          >
            Next <ChevronRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
