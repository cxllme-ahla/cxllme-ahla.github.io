# Tech Spec — StarkInsider Blog

## Dependencies

### Runtime
| Package | Version | Purpose |
|---------|---------|---------|
| react | ^19.0.0 | UI framework |
| react-dom | ^19.0.0 | DOM renderer |
| react-router-dom | ^7.1.0 | Client-side routing (Home, Post, Archive, About, Contact) |
| gsap | ^3.12.0 | Animation engine — ScrollTrigger, Flip, timelines |
| lenis | ^1.2.0 | Smooth scroll with inertia |
| ogl | ^1.0.0 | WebGL library for the Hero 3D Typographic Ring |
| normalize-wheel | ^1.0.0 | Cross-browser scroll normalization for the WebGL cylinder |
| imagesloaded | ^5.0.0 | Image preload detection for scroll-trigger layout stability |
| react-markdown | ^9.0.0 | Render Markdown article content |
| remark-gfm | ^4.0.0 | GitHub Flavored Markdown (tables, strikethrough, task lists) |
| react-syntax-highlighter | ^15.6.0 | Syntax-highlighted code blocks in articles |
| lucide-react | ^0.468.0 | Icon set (search, menu, share, arrows, social) |

### Dev / Tooling
| Package | Version | Purpose |
|---------|---------|---------|
| vite | ^6.3.0 | Build tool |
| @vitejs/plugin-react | ^4.4.0 | React fast-refresh for Vite |
| typescript | ^5.7.0 | Type safety |
| tailwindcss | ^4.1.0 | Utility CSS |
| @tailwindcss/vite | ^4.1.0 | Tailwind Vite integration |

### Fonts (loaded via Google Fonts CDN in index.html)
- `Instrument Serif` — Editorial headings, hero 3D text
- `Inter` — UI, navigation, body copy, metadata

---

## Component Inventory

### Layout (shared across all pages)
| Component | Source | Reuse |
|-----------|--------|-------|
| Navbar | Custom | All pages — sticky with blur backdrop, nav links, search icon |
| SearchOverlay | Custom | All pages — fullscreen overlay with live search |
| Footer | Custom | All pages — 3-column layout with links |
| FloatingActionButton | Custom | All pages — back-to-top, appears after scroll |
| ReadingProgressBar | Custom | Post page only — thin gold bar fixed at viewport top |
| Layout | Custom | Wraps all pages — provides Lenis instance, scroll restoration, progress bar slot |

### Sections — Homepage
| Component | Source | Notes |
|-----------|--------|-------|
| HeroSection | Custom | Contains the WebGL canvas + caption + scroll indicator |
| FeaturedPost | Custom | Full-width image + editorial text (60% width) + image reveal |
| LatestGrid | Custom | 3-column article grid with hover dim behavior |
| LoadMore | Custom | "Load More" button + infinite scroll append logic |

### Sections — Post Page
| Component | Source | Notes |
|-----------|--------|-------|
| Breadcrumb | Custom | "Home / Category / Title" trail |
| ArticleHeader | Custom | Title + author meta + reading time + social share row |
| ArticleBody | Custom | react-markdown wrapper with custom components for headings, code, blockquote, images |
| ArticleTags | Custom | Tag pills linking to filtered archive |
| GiscusComments | Custom | Giscus embed with dark theme, skeleton loading state |
| RelatedPosts | Custom | 3-column card grid filtered by category/tags |
| PostNavigation | Custom | Previous / Next article links |

### Sections — Archive Page
| Component | Source | Notes |
|-----------|--------|-------|
| ArchiveHeader | Custom | Title + subtitle + article count |
| FilterBar | Custom | Sticky bar — category dropdown, tag pills, sort toggle, view toggle |
| ArticleGrid | Custom | 3-column grid view (shared card component with LatestGrid) |
| ArticleList | Custom | Single-column list view with horizontal rows |
| Pagination | Custom | Page numbers + prev/next with ellipsis logic |
| EmptyState | Custom | Shown when filters match zero articles |

### Sections — Static Pages
| Component | Source | Notes |
|-----------|--------|-------|
| AboutContent | Custom | Profile image + bio + social links + stats row |
| ContactForm | Custom | Name/email/message form with validation + success state |

### Reusable Components
| Component | Source | Used By |
|-----------|--------|---------|
| ArticleCard | Custom | LatestGrid, ArticleGrid, RelatedPosts — thumbnail + title + excerpt + meta |
| EditorialImageReveal | Custom | FeaturedPost, ArticleCard — GSAP clip-path + blur reveal on scroll |
| SkeletonLoader | Custom | LatestGrid, ArticleGrid, GiscusComments — pulse animation placeholder |
| TagPill | Custom | ArticleCard, ArticleTags, FilterBar — clickable tag with hover state |
| SocialShareRow | Custom | ArticleHeader — Twitter/X, Facebook, LinkedIn, Copy Link icons |

### Hooks
| Hook | Purpose |
|------|---------|
| useLenis | Initialize and expose Lenis instance for smooth scroll + scrollTo |
| useScrollReveal | GSAP ScrollTrigger fade-up entrance for any element |
| useReadingTime | Calculate estimated reading time from word count |
| useLocalStorage | Persist theme preference, search history |

---

## Animation Implementation

| Animation | Library | Approach | Complexity |
|-----------|---------|----------|------------|
| Hero 3D Typographic Ring | OGL (raw WebGL) + custom shaders | Cylinder geometry with word textures UV-mapped. Vertex shader applies mouse-driven rotation matrices + time-based sine displacement. Fragment shader samples a letter atlas texture scrolled by `uScrollY`. Requires offscreen canvas for text rasterization. | **High** 🔒 |
| Editorial Image Reveal | GSAP ScrollTrigger | `clipPath: inset()` animates cover away while inner image scales from 1.4→1 and blur clears 15px→0. Both animations on same timeline start position. | Medium |
| Scroll Entrance (global) | GSAP ScrollTrigger | Elements translate Y 40px + fade 0→1 on viewport entry. Applied via `useScrollReveal` hook. | Low |
| Search Overlay | GSAP | Overlay fades in (0.3s), input slides down from top (0.4s, power3.out). Reverse on close. | Low |
| Link Underline Hover | CSS | `transform: scaleX(0→1)` on `::after` pseudo-element, `transform-origin: left`. Pure CSS transition. | Low |
| Card Hover Dim | CSS | Sibling opacity reduction via parent `:hover` — hovered card 100%, siblings 60%. CSS transition. | Low |
| FAB Appear/Disappear | GSAP | Scale 0→1 after 500px scroll. Power3.out ease. | Low |
| Reading Progress Bar | GSAP ScrollTrigger | `scaleX` tied to article scroll progress. Opacity 0→1 after 100px scroll. | Low |
| Load More Append | GSAP | New cards fade in (opacity 0→1) + translateY (20px→0) over 0.5s. | Low |
| Skeleton Loading | CSS | `@keyframes pulse` animation on placeholder rectangles. | Low |
| Smooth Scroll | Lenis | Global instance with `lerp: 0.1`, `wheelMultiplier: 1.4`. Integrated with GSAP ScrollTrigger via `lenis.on('scroll', ScrollTrigger.update)`. | Low |

---

## State & Logic Plan

### Markdown Content Pipeline
Articles are stored as `.md` files in a `content/` directory. A Vite plugin or build-time script parses these files (frontmatter + body) into a JSON manifest. At runtime, the app loads this manifest for listings and fetches individual `.md` files for article rendering via `react-markdown` + `remark-gfm`.

### Routing
React Router v7 with routes: `/` (Home), `/post/:slug` (Post), `/archive` (Archive), `/about` (About), `/contact` (Contact). The blog is a SPA — all navigation is client-side. Scroll position resets on route change via Lenis `scrollTo(0)`.

### Search
The search overlay performs client-side filtering against the article manifest (title, excerpt, tags). No server needed — results are instant.

### Archive Filtering
Category and tag filters are URL-driven (query params: `?category=tech&tag=react`). On mount, the Archive page reads params, applies filters to the article manifest, and paginates results. Changing filters resets to page 1.

### View Transitions
Native CSS View Transitions API used for page transitions. On navigation, `document.startViewTransition()` wraps the route change. Elements with `view-transition-name` (e.g., article thumbnails) animate smoothly between pages.

---

## Other Key Decisions

### WebGL Renderer Choice
Use `ogl` (not Three.js). The design specifies raw WebGL with custom shaders — `ogl` is a minimal, lightweight WebGL framework that provides exactly the right abstraction level (Renderer, Camera, Geometry, Mesh, Program, Texture) without the overhead of a full scene graph. This keeps the bundle size small and gives full shader control.

### No shadcn/ui Components
The design is fully bespoke with 1px border aesthetics, custom hover states, and no standard form patterns. shadcn's default styling (rounded corners, shadow-based elevation) conflicts with the StarkInsider visual language. All components are custom-built with Tailwind.

### PWA Strategy
A service worker (generated via Vite PWA plugin) caches static assets and article content. The app includes a `manifest.json` for installability. Offline mode serves cached pages.

### RSS Feed
A build-time script generates an `rss.xml` file from the article manifest. Static file served from `public/`.

### Giscus Integration
Giscus is loaded via its `<script>` embed in the GiscusComments component. The script is dynamically injected on mount to avoid loading on pages without comments. Dark theme is forced to match the site palette.
